package com.example.tareasensores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button _btnSProximidad, _btnSLuminosidad;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        _btnSProximidad = (Button) findViewById(R.id.btnSProximidad);
        _btnSLuminosidad = (Button) findViewById(R.id.btnSLuminosidad);

        _btnSProximidad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SensorProximidad.class);
                startActivity(intent);
            }
        });

        _btnSLuminosidad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, SensorLuminosidad.class);
                startActivity(i);

            }
        });
    }
}