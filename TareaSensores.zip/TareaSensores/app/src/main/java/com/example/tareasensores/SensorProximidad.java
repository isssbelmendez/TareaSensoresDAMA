package com.example.tareasensores;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class SensorProximidad extends AppCompatActivity {
    Sensor miSensor;
    SensorManager administradorDeSensores;
    SensorEventListener disparadorEventoSensor;
    Button _btnValor;

    ConstraintLayout _main;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_proximidad);
        _btnValor = (Button) findViewById(R.id.btnValor);

        _main = findViewById(R.id.mainL);
        //INICIALIZAR MI SENSOR
        administradorDeSensores = (SensorManager) getSystemService(SENSOR_SERVICE);
        miSensor = administradorDeSensores.getDefaultSensor(Sensor.TYPE_PROXIMITY);

        if(miSensor == null){
            Toast.makeText(this, "Su dispositivo no cuenta con el sensor de proximidad", Toast.LENGTH_LONG).show();
            finish();
        }else{
            Toast.makeText(this, "Sensor de proximidad detectado", Toast.LENGTH_LONG).show();
        }

        disparadorEventoSensor = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent sensorEvent) {

                _btnValor.setText("Valor: "+sensorEvent.values[0]);

                if(sensorEvent.values[0] < miSensor.getMaximumRange()){
                    //Condicion para determinar cuando se acerque
                    _main.setBackgroundColor(Color.YELLOW);
                    _btnValor.setBackgroundColor(Color.BLUE);
                }else{
                    _main.setBackgroundColor(Color.WHITE);
                    _btnValor.setBackgroundColor(Color.RED);
                }
            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int i) {

            }
        };
        iniciarSensor();
    }
    private void iniciarSensor() {
        administradorDeSensores.registerListener(disparadorEventoSensor, miSensor, (2000*1000) );
    }

    public void detenerSensor(){
        administradorDeSensores.unregisterListener(disparadorEventoSensor);
    }

    @Override
    protected void onPause(){
        detenerSensor();
        super.onPause();
    }

    @Override
    protected void onResume(){
        iniciarSensor();
        super.onResume();
    }
}