package com.example.tareasensores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class SensorLuminosidad extends AppCompatActivity {
    Sensor _lightSensor;
    SensorManager _sensorManager;
    SensorEventListener _lightEventListener;
    View _root;
    float _valorMax;
    TextView _lbValor, _lbMensaje;
    Button _btnResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_luminosidad);

        _root = findViewById(R.id.mainLayout);
        _lbValor = findViewById(R.id.lbValor);
        _lbMensaje = findViewById(R.id.lbMensaje);
        _btnResultado = findViewById(R.id.btnResultado);

        // Inicializar Sensor
        _sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        _lightSensor = _sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);

        if (_lightSensor == null) {
            Toast.makeText(this, "No se detectó el sensor de luminosidad", Toast.LENGTH_LONG).show();
            finish();
        } else {
            Toast.makeText(this, "Sensor de luminosidad detectado", Toast.LENGTH_LONG).show();
        }

        _valorMax = _lightSensor.getMaximumRange();

        _lightEventListener = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent sensorEvent) {
                float luz = sensorEvent.values[0];
                _lbValor.setText("Cantidad de Internet: " + luz);
            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int i) {

            }
        };

        _btnResultado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Obtener el valor actual
                String valorActual = _lbValor.getText().toString();

                // Enviar mensaje a través de WhatsApp
                enviarMensajeWhatsApp(valorActual);
            }
        });
    }

    private void enviarMensajeWhatsApp(String mensaje) {
        // Verificar si WhatsApp está instalado
        PackageManager packageManager = getPackageManager();
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, mensaje);

        try {
            packageManager.getPackageInfo("com.whatsapp", PackageManager.GET_ACTIVITIES);
            intent.setPackage("com.whatsapp");
        } catch (PackageManager.NameNotFoundException e) {
            Toast.makeText(this, "WhatsApp no está instalado", Toast.LENGTH_SHORT).show();
            return;
        }

        // Abrir la actividad de WhatsApp
        startActivity(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        _sensorManager.registerListener(_lightEventListener, _lightSensor, SensorManager.SENSOR_DELAY_FASTEST);
    }

    @Override
    protected void onPause() {
        super.onPause();
        _sensorManager.unregisterListener(_lightEventListener);
    }
}
